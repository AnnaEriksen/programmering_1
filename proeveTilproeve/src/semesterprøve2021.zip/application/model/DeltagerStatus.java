package application.model;

public enum DeltagerStatus {
    TILSTEDE, FRAVÆR, SYG, AFBUD
}
